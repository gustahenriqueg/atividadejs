function media() {
    a = 4;
    b = 12;
    c = 15;
    resultado = (a + b + c) / 3;
    alert(resultado);
}