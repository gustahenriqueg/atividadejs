function imprimir() {
    var num1 = document.getElementById("num1").value;
    var num2 = document.getElementById("num2").value;
    alert(num1 + "\n" + num2);
}