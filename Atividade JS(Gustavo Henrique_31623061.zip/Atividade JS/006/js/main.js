function imprimir() {
    var num = document.getElementById("num").value;
    alert("O número inteiro digitado foi " + num); }