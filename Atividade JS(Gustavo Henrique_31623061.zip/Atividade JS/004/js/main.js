function soma() {
    a = 25;
    b = 27;
    adicao = a + b;
    alert(adicao);
}