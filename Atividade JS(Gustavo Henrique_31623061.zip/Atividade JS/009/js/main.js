function imprimir() {
    var nome = document.getElementById("nome").value;
    var endereco = document.getElementById("endereco").value;
    var tel = document.getElementById("tel").value;
    alert("Nome:" + nome + "\n Endereço:" + endereco + "\n Telefone:" + tel);
}