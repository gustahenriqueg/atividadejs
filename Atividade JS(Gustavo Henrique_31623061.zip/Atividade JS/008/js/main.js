function imprimir() {
    var num = document.getElementById("num").value;
    antec = parseInt(num) - 1;
    suces = parseInt(num) + 1;
    document.write("Seu antecessor é " + antec + " e o seu sucessor é " + suces);
}