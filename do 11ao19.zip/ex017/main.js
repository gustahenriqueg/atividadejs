function calc(){
    var salario = document.getElementById("salario").value;
    var perc_aumento = document.getElementById("perc_aumento").value;
    aumento = parseFloat(salario) * (parseFloat(perc_aumento) / 100);
    nsalario = parseFloat(salario) + parseFloat(aumento);
   alert("O aumento é de: R$" + aumento + "\n O novo salário é de: R$" + nsalario);

}