function calc(){
    var salario = document.getElementById("salario").value;
    bonificacao = 50;
    imposto = parseFloat(salario) * 0.10;
    nsalario = parseFloat(salario) + bonificacao - imposto;
   alert("O salário é de : R$" + nsalario);

}