function calc(){
    var salario = document.getElementById("salario").value;
    nsalario = parseFloat(salario) + (parseFloat(salario) * 0.25);
   alert("O valor do salário é R$ " + nsalario);

}