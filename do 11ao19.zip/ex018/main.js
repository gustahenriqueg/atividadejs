function calcular(){
    var salario = document.getElementById("salario").value;
    bonificacao = parseFloat(salario) * 0.05;
    imposto = parseFloat(salario) * 0.07;
    nsalario = parseFloat(salario) + gratificacao - imposto;
   alert("O novo salário é de: R$" + nsalario);

}