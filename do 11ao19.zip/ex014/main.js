function calcular(){
    var numero1 = document.getElementById("numero1").value;
    var numero2 = document.getElementById("nnumero2").value;
    var numero3 = document.getElementById("numero3").value;
    media = (parseFloat(numero1) + parseFloat(numero2) + parseFloat(numero3)) / 3;
   alert("A média das notas são -  " + media);