function calcular(){
    var numero1 = document.getElementById("numero1").value;
    var numero2 = document.getElementById("numero2").value;
    var numero3 = document.getElementById("numero3").value;
    var pon1 = document.getElementById("pon1").value;
    var pon2 = document.getElementById("pon2").value;
    var pon3 = document.getElementById("pon3").value;
    media = ((parseFloat(numero1) * parseFloat(pon1)) + (parseFloat(numero2) * parseFloat(pon2)) + (parseFloat(numero3) * parseFloat(pon3))) / (parseFloat(pon1) + parseFloat(pon2) + parseFloat(pon3));
   alert("A média ponderada das são -  " + media);
}