function calc(){
    var numero = document.getElementById("num").value;
    resultado = parseInt(numero) / 3;
    alert(resultado);
}