function calcular(){
    var numero1 = document.getElementById("numero1").value;
    var numero2 = document.getElementById("numero2").value;
    dividendo = num1;
    divisor = num2;
    quociente = dividendo / divisor;
    
	resto = dividendo % divisor;
   alert("Dividendo: " + dividendo + "\nDivisor: " + divisor + "\nQuociente: " + quociente + "\nResto: " + resto);
}